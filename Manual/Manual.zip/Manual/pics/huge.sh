cat $1.tex | sed "s/LARGE/Huge/g" > $1_neu.tex
mv $1_neu.tex $1.tex
latex $1.tex
latex $1.tex
dvips $1.dvi
convert $1.ps $1.eps
epstopdf $1.eps
